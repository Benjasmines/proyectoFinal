# 1. Terraform crea el .zip automáticamente por ti
data "archive_file" "zip_amenazas" {
  type        = "zip"
  source_file = "${path.module}/backend/lambda_amenazas.py" # Ruta a tu script
  output_path = "${path.module}/backend/lambda_amenazas.zip" # Donde guardará el zip temporal
}

# 2. Creas la función Lambda apuntando a ese .zip
resource "aws_lambda_function" "lambda_amenazas" {
  function_name = "api-amenazas-ciberseguridad"
  
  # Aquí le pasas el archivo .zip que Terraform acaba de crear
  filename         = data.archive_file.zip_amenazas.output_path
  source_code_hash = data.archive_file.zip_amenazas.output_base64sha256

  # Le decimos que busque el archivo "lambda_amenazas" y ejecute "lambda_handler"
  handler = "lambda_amenazas.lambda_handler" 
  runtime = "python3.10" # O la versión de Python que prefieras

  # Recuerda que necesitas un Rol de IAM básico para que la Lambda pueda ejecutarse
  role = aws_iam_role.rol_para_lambda.arn 
}
